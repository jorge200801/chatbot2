console.log("funciona")
window.alert("Esta Pagina usa Politicas de privacidad")

function mostrar(){
    var correo=document.form.email.value;
    var ciudades=document.form.ciudades.value;
    var curso=document.form.radio.value;
    var calendario=document.form.date.value;

   
    

    window.alert('email: '+ correo); 
    window.alert('Ciudades: '+ ciudades); 
    window.alert('Curso: '+ curso); 
    window.alert('Fecha: '+ calendario); 

    var hoy = new Date();
    var calendario = new Date(date);

    hoy.setHours(0,0,0,0);
    if(hoy >= date){
        window.alert("Coge otra fecha posterior a la de hoy");
    }
    

}
