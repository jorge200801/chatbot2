var modulo;
var imparesarray = [];
var total = 0;
var numero = prompt("Escribe un numero del 1 al 100");
if (numero <= 100) {
    for (var impares = numero; impares <= 1000; impares++) {
        modulo = impares%2;
        if( modulo != 0){
            imparesarray.push(impares);

            total= total+parseInt(impares);
        }
        
    }
    window.alert(imparesarray);
    window.alert(total);
}else{
    window.alert("El numero sobrepasa la cifra dada");
}