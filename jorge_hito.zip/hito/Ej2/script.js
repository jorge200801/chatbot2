console.log("funciona");
function ocultar(){

 document.getElementById("img").style.display = "none";
}

function mostrar()
{
    document.getElementById("img").style.display = "block";
}

//mover caja
let cajamovil = document.getElementById("movebox");

//Contenedores
let contarAbajo = 600;

function abjao(){
    contarAbajo = contarAbajo +20;
    cajamovil.style.top = contarAbajo + "px";
}

cajamovil.addEventListener("click",abjao);